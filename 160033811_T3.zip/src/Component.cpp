#include "Component.h"
#include "GameObject.h"

// Component :: Component() {

// }

Component :: ~Component() {

}

Component :: Component(GameObject& associated) : associated(associated) {
    
}