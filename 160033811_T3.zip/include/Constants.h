#ifndef CONSTANTS_H
#define CONSTANTS_H
namespace Const {
  const int DELAY = 33;
  struct FULL_HD {
    static const int heigh = 1080;
    static const int width = 1920;

  };
}

#endif